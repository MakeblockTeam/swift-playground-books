//
//  NeuronPackage.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public enum NeuronPackageType {
    case unknown
    case dispatch
    case funnyTouch
    case knob
    case gyroSensor
    case temperature
    case soilMoisture
    case light
    case distance
    case voice
}

extension Data {
    var typeByte: UInt8? {
        return count > 2 ? self.bytes[2] : nil
    }

    var subTypeByte: UInt8? {
        return count > 3 ? self.bytes[3] : nil
    }
}

protocol NeuronPackageProtocol {
    var length: Int {get}
    var typeCode: NeuronTypeCode {get}
    var subTypeCode: UInt8? {get}

    func isValid(data: Data) -> Bool
}

open class NeuronPackage: NeuronPackageProtocol {
    var length: Int {
        return 0
    }

    var typeCode: NeuronTypeCode {
        return .unknown
    }

    var subTypeCode: UInt8? {
        return nil
    }

    public var blockNo: Int = 0x00
    public var data: Data

    public init(data: Data) {
        self.data = data
        if data.count > 1 {
            blockNo = Int(data.bytes[1])
        }
    }

    public func isValid(data: Data) -> Bool {
        if subTypeCode != nil {
            return (data.count > length-1) &&
                (data.typeByte == typeCode.rawValue) &&
                (data.subTypeByte == subTypeCode)
        } else {
            return (data.count > length-1) &&
                (data.typeByte == typeCode.rawValue)
        }
    }
}

open class DispatchPackage: NeuronPackage {
    override var length: Int {
        return 7
    }

    override var typeCode: NeuronTypeCode {
        return NeuronTypeCode.dispatch
    }

    public var type: UInt8 = 0x00
    public var subType: UInt8 = 0x00
    public var blockType: BlockType? {
        return BlockType.getType(type: type, subType: subType)
    }

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            type = data.bytes[3]
            subType = data.bytes[4]
        }
    }
}

open class ControlPackage: NeuronPackage {
    override var typeCode: NeuronTypeCode {
        return NeuronTypeCode.control
    }
}

open class FunnyTouchPackage: ControlPackage {
    override var length: Int {
        return 8
    }

    override var subTypeCode: UInt8? {
        return BlockType.funnyTouch.subTypeCode
    }

    public var blueTouched: Bool = false
    public var yellowTouched: Bool = false
    public var redTouched: Bool = false
    public var greenTouched: Bool = false

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            let value = data.bytes[5]
            blueTouched = ((value & 0x01) == 0x01)
            yellowTouched = ((value & 0x02) == 0x02)
            redTouched = ((value & 0x04) == 0x04)
            greenTouched = ((value & 0x08) == 0x08)
        }
    }
}

open class KnobPackage: ControlPackage {
    override var length: Int {
        return 8
    }

    override var subTypeCode: UInt8? {
        return BlockType.knob.subTypeCode
    }
    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            value = Int(data.bytes[5])
        }
    }
}

open class SensorPackage: NeuronPackage {
    override var typeCode: NeuronTypeCode {
        return NeuronTypeCode.sensor
    }
}

open class GyroSensorPackage: SensorPackage {
    override var length: Int {
        return 8
    }

    override var subTypeCode: UInt8? {
        return BlockType.gyro.subTypeCode
    }

    public var dataType: GyroDataType = .unknown
    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            if let dataType = GyroDataType(rawValue: data.bytes[4]) {
                self.dataType = dataType
            }

            if dataType == GyroDataType.shake {
                value = Int(data.bytes[5])

            } else if dataType == GyroDataType.xAngle ||
                dataType == GyroDataType.yAngle ||
                dataType == GyroDataType.zAngle {
                let valueData = data.subdata(in: 5..<8)
                let valueBytes = DataConverter.convert7to8bit(valueData.bytes)
                value = Int(ByteArrayConverter.fromByteArray(valueBytes, CShort.self))
            }
        }
    }
}

open class TemperaturePackage: SensorPackage {
    override var length: Int {
        return 12
    }

    override var subTypeCode: UInt8? {
        return  BlockType.temperature.subTypeCode
    }

    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            let valueData = data.subdata(in: 5..<10)
            let valueBytes = DataConverter.convert7to8bit(valueData.bytes)
            value = Int(ByteArrayConverter.fromByteArray(valueBytes, Float.self))
        }
    }
}

open class LightPackage: SensorPackage {
    override var length: Int {
        return 8
    }

    override var subTypeCode: UInt8? {
        return BlockType.light.subTypeCode
    }

    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            value = Int(data.bytes[5])
        }
    }
}

open class DistancePackage: SensorPackage {
    override var length: Int {
        return 12
    }

    override var subTypeCode: UInt8? {
        return BlockType.distance.subTypeCode
    }

    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            let valueData = data.subdata(in: 5..<10)
            let valueBytes = DataConverter.convert7to8bit(valueData.bytes)
            value = Int(ByteArrayConverter.fromByteArray(valueBytes, Float.self))
        }
    }
}

open class VoicePackage: SensorPackage {
    override var length: Int {
        return 8
    }

    override var subTypeCode: UInt8? {
        return BlockType.voice.subTypeCode
    }

    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            value = Int(data.bytes[5])
        }
    }
}

open class SoilMoisturePackage: SensorPackage {
    override var length: Int {
        return 8
    }

    override var subTypeCode: UInt8? {
        return BlockType.soilMoisture.subTypeCode
    }

    public var value: Int = 0

    public override init(data: Data) {
        super.init(data: data)
        if isValid(data: data) {
            value = Int(data.bytes[5])
        }
    }
}
