//
//  NeuronPackage.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import Foundation

public protocol NeuronPackageInterpreterDelegate: class {
    func onReceive(knobPackage: KnobPackage)
    func onReceive(funnyTouchPackage: FunnyTouchPackage)
    func onReceive(gyroSensorPackage: GyroSensorPackage)
    func onReceive(temperaturePackage: TemperaturePackage)
    func onReceive(lightPackage: LightPackage)
    func onReceive(distancePackage: DistancePackage)
    func onReceive(voicePackage: VoicePackage)
    func onReceive(soilMoisturePackage: SoilMoisturePackage)
    func onReceive(unkonwnPackage: Data)
}

public protocol DispatchPackageDelegate: class {
    func onReceive(dispatchPackage: DispatchPackage)
}

open class NeuronPackageInterpreter {
    public weak var delegate: NeuronPackageInterpreterDelegate?
    public weak var dispatchPackageDelegate: DispatchPackageDelegate?

    public init() {
    }

    public func received(data: Data) {
        let type = getType(data: data)

        switch type {
        case .dispatch:
            dispatchPackageDelegate?.onReceive(dispatchPackage: DispatchPackage(data: data))
        case .unknown:
            delegate?.onReceive(unkonwnPackage: data)
        case .funnyTouch:
            delegate?.onReceive(funnyTouchPackage: FunnyTouchPackage(data: data))
        case .knob:
            delegate?.onReceive(knobPackage: KnobPackage(data: data))
        case .gyroSensor:
            delegate?.onReceive(gyroSensorPackage: GyroSensorPackage(data: data))
        case .temperature:
            delegate?.onReceive(temperaturePackage: TemperaturePackage(data: data))
        case .soilMoisture:
            delegate?.onReceive(soilMoisturePackage: SoilMoisturePackage(data: data))
        case .voice:
            delegate?.onReceive(voicePackage: VoicePackage(data: data))
        case .light:
            delegate?.onReceive(lightPackage: LightPackage(data: data))
        case .distance:
            delegate?.onReceive(distancePackage: DistancePackage(data: data))
        }
    }

    private func getType(data: Data) -> NeuronPackageType {
        guard let typeByte = data.typeByte,
            let type = NeuronTypeCode.init(rawValue: typeByte) else {
                return .unknown
        }

        switch type {
        case .dispatch:
            return .dispatch
        case .sensor:
            if data.subTypeByte ==  BlockType.gyro.subTypeCode {
                return .gyroSensor
            } else if data.subTypeByte == BlockType.temperature.subTypeCode {
                return .temperature
            } else if data.subTypeByte == BlockType.light.subTypeCode {
                return .light
            } else if data.subTypeByte == BlockType.distance.subTypeCode {
                return .distance
            } else if data.subTypeByte == BlockType.voice.subTypeCode {
                return .voice
            } else if data.subTypeByte == BlockType.soilMoisture.subTypeCode {
                return .soilMoisture
            } else {
                return .unknown
            }
        case .control:
            if data.subTypeByte == BlockType.funnyTouch.subTypeCode {
                return .funnyTouch
            } else if data.subTypeByte == BlockType.knob.subTypeCode {
                return .knob
            } else {
                return .unknown
            }
        default:
            return .unknown
        }
    }
}
