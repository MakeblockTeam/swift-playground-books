//
//  Neuron.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

open class Neuron: NSObject {
    public weak var interpreterDelegate: NeuronPackageInterpreterDelegate?

    public weak var blockContainerDelegate: BlockContainerDelegate? {
        didSet {
            blockContainer.delegate = blockContainerDelegate
        }
    }

    private var timer: Timer?
    private let parse = NeuronDataParser()
    private var sender: MakeblockSender?
    private let interpreter = NeuronPackageInterpreter()
    private let blockContainer = BlockContainer()
    private var buzzerQueueCommand: QueueCommand?
    private var knobCallback: ((KnobPackage) -> Void)?
    private var lightCallback: ((LightPackage) -> Void)?
    private var temperatureCallback: ((TemperaturePackage) -> Void)?
    private var funnyTouchCallback: ((FunnyTouchPackage) -> Void)?
    private var distanceCallback: ((DistancePackage) -> Void)?

    public init(sender: MakeblockSender) {
        super.init()
        self.sender = sender
        parse.delegate = self
        interpreter.dispatchPackageDelegate = self
        interpreter.delegate = self
    }

    // MARK: Public Methods

    public func startHeartbeat() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 0.5,
                                     target: self,
                                     selector: #selector(sendHeartbaet),
                                     userInfo: nil,
                                     repeats: true)
    }

    public func stopHeartbeat() {
        timer?.invalidate()
    }

    public func setDataReportWay(block: BlockType, way: DataReportWay, timeIntervalInMs: Float) {
        send(command: DataReportWayCommand(block: block,
                                           way: way,
                                           timeIntervalInMs: timeIntervalInMs))
    }

    public func subscribeGyroData(dataType: GyroDataType, way: DataReportWay, timeIntervalInMs: Float) {
        send(command: SubscribeGyroDataCommand(dataType: dataType,
                                               way: way,
                                               timeIntervalInMs: timeIntervalInMs))
    }

    public func cancelSubscribeGyroData(dataType: GyroDataType) {
        send(command: CancelSubscribeGyroDataCommand(dataType: dataType))
    }

    public func setBuzzer(pitch: SoundNote, volume: Int = 50) {
        send(command: BuzzerCommand(pitch: pitch, volume: volume))
    }

    public func setBuzzer(pitch: SoundNote, duration: SoundBeat, volume: Int = 50) {
        guard let sender = sender else {
            return
        }

        buzzerQueueCommand?.cancel()

        let buzzerCommand = BuzzerCommand(pitch: pitch, volume: volume)
        let stopCommand = BuzzerCommand(pitch: pitch, volume: 0)
        buzzerQueueCommand = QueueCommand(queue: [buzzerCommand, stopCommand],
                                          timeIntervals: [TimeInterval(duration.rawValue)/1000.0],
                                          sender: sender)
        buzzerQueueCommand?.execute(callback: nil)
    }

    public func setServo(port: ServoPort, angle: Int) {
        send(command: ServoCommand(port: port, angle: angle))
    }

    public func setDCMotor(slot: DCMotorSlot, speed: Int) {
        send(command: DCMotorCommand(slot: slot, speed: speed))
    }

    public func setBothDCMotor(speed1: Int, speed2: Int) {
        send(command: BothDCMotorCommand(speed1: speed1, speed2: speed2))
    }

    public func setRGBLED(x: Int,
                          y: Int,
                          red: Int,
                          green: Int,
                          blue: Int) {
        send(command: RGBLEDCommand(x: x, y: y, red: red, green: green, blue: blue))
    }

    public func setLEDMatrix(colors: [[Int]]) {
        let colorsStd = colors.reduce([]) { (r, e) -> [Int] in
            return r + e
        }
        send(command: LEDMatrixCommand.init(amount: colorsStd.count, colors: colorsStd, displayMode: 0))
    }

    public func setLEDColor(_ color: LEDColor, animateMode: LEDStyle = .light, animateSpeed: Int = 2) {
        let colors = (0..<30).map {_ in color}
        send(command: LEDBandCommand.init(amount: colors.count, colors: colors, animateMode: animateMode, animateSpeed: animateSpeed))
    }

    public func setLEDColors(_ colors: [LEDColor], animateMode: LEDStyle = .light, animateSpeed: Int = 2) {
        send(command: LEDBandCommand.init(amount: colors.count, colors: colors, animateMode: animateMode, animateSpeed: animateSpeed))
    }

    public func clearRGBLED() {
        send(command: RGBLEDCommand(x: 0, y: 0, red: 0, green: 0, blue: 0))
    }

    public func getKnob(callback: ((KnobPackage) -> Void)? = nil) {
        self.knobCallback = callback
        send(command: GetKnobCommand())
    }

    public func getLight(callback: ((LightPackage) -> Void)? = nil) {
        self.lightCallback = callback
        send(command: GetLightCommand())
    }

    public func getTemperature(callback: ((TemperaturePackage) -> Void)? = nil) {
        self.temperatureCallback = callback
        send(command: GetTemperatureCommand())
    }

    public func getFunnyTouch(callback: ((FunnyTouchPackage) -> Void)? = nil) {
        self.funnyTouchCallback = callback
        send(command: GetFunnyTouchCommand())
    }

    public func getDistance(callback: ((DistancePackage) -> Void)? = nil) {
        self.distanceCallback = callback
        send(command: GetDistanceCommand())
    }

    public func receivedData(_ data: Data) {
        parse.addReceived(data: data)
    }

    // MARK: Private Methods

    @objc private func sendHeartbaet() {
        send(command: HeartbeatCommand())
    }

    private func send(command: MakeblockCommand) {
        sender?.send(data: command.data)
    }
}

extension Neuron: NeuronDataParserDelegate {
    public func onParseData(_ data: Data) {
        interpreter.received(data: data)
    }

    public func onParseErrorData(_ data: Data) {
        debugPrint("onParseErrorData: \(data.hexString)")
    }

    public func onBufferOverflow(length: Int) {
        debugPrint("onBufferOverflow: \(length)")
    }
}

extension Neuron: DispatchPackageDelegate {
    public func onReceive(dispatchPackage: DispatchPackage) {
        blockContainer.receive(dispatchPackage: dispatchPackage)
    }
}

extension Neuron: NeuronPackageInterpreterDelegate {
    public func onReceive(knobPackage: KnobPackage) {
        interpreterDelegate?.onReceive(knobPackage: knobPackage)
        knobCallback?(knobPackage)
        knobCallback = nil
    }

    public func onReceive(funnyTouchPackage: FunnyTouchPackage) {
        interpreterDelegate?.onReceive(funnyTouchPackage: funnyTouchPackage)
        funnyTouchCallback?(funnyTouchPackage)
        funnyTouchCallback = nil
    }

    public func onReceive(gyroSensorPackage: GyroSensorPackage) {
        interpreterDelegate?.onReceive(gyroSensorPackage: gyroSensorPackage)
    }

    public func onReceive(temperaturePackage: TemperaturePackage) {
        interpreterDelegate?.onReceive(temperaturePackage: temperaturePackage)
        temperatureCallback?(temperaturePackage)
        temperatureCallback = nil
    }

    public func onReceive(lightPackage: LightPackage) {
        interpreterDelegate?.onReceive(lightPackage: lightPackage)
        lightCallback?(lightPackage)
        lightCallback = nil
    }

    public func onReceive(distancePackage: DistancePackage) {
        interpreterDelegate?.onReceive(distancePackage: distancePackage)
        distanceCallback?(distancePackage)
        distanceCallback = nil
    }

    public func onReceive(voicePackage: VoicePackage) {
        interpreterDelegate?.onReceive(voicePackage: voicePackage)
    }

    public func onReceive(soilMoisturePackage: SoilMoisturePackage) {
        interpreterDelegate?.onReceive(soilMoisturePackage: soilMoisturePackage)
    }

    public func onReceive(unkonwnPackage: Data) {
        interpreterDelegate?.onReceive(unkonwnPackage: unkonwnPackage)
    }
}
