//
//  LiveViewController.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit
import PlaygroundSupport
import PlaygroundBluetooth
import AVFoundation

public struct BlockWithValue {
    var block: BlockType
    var value: [Int]
}

public class TemplateViewController: LiveViewController {
    fileprivate var logView: UIButton!
    private var bgView: NeuronBgView!
    private var containerView: NeuronContainerView!
    private var tiltDetector = TiltDetector()
    
    private let neuronListener = NeuronListener()
    
    fileprivate var lastNote: PadSoundNote = .unknown
    
    // MARK: LifeCycle
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setBackgroundAudio(visible: false)
        setupContainerView()
        tiltDetector.delegate = self
        SPBLECenter.shared.isNeuron = true
        currentBot.interpreterDelegate = neuronListener
        currentBot.blockContainerDelegate = neuronListener
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tiltDetector.start()
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tiltDetector.stop()
    }
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let screenMode = getScreenMode(frame: view.frame)
        bgView.refresh(screenMode: screenMode, frame: view.frame)
    }
    
    override public func didDisconnect() {
        self.bgView.changeToDisConnected()
        self.containerView.isHidden = true
    }
    
    override public func didPrepared() {
        self.bgView.changeToConnected()
        self.containerView.isHidden = false
    }
    
    public override func didReceive(data: Data) {
        currentBot.receivedData(data)
    }
    
    // MARK: Public Methods
    
    public func connect(block: BlockType, position: Int) {
        if !block.isInput {
            return
        }
        
        var value = [Int]()
        if block == .funnyTouch {
            value = [0, 0, 0, 0]
        } else {
            value = [0]
        }
        let blockWithValue = BlockWithValue.init(block: block, value: value)
        containerView.add(block: blockWithValue)
    }
    
    public func disConnect(block: BlockType, position: Int) {
        if !block.isInput {
            return
        }
        containerView.remove(block: block)
    }
    
    public func receive(blockWithValue: BlockWithValue) {
        if !blockWithValue.block.isInput {
            return
        }
        
        containerView.update(block: blockWithValue)
    }
    
    public func iPadSound(note: PadSoundNote) {
        if note == lastNote, let player = player, player.isPlaying {
            return
        }
        
        stopMusic()
        lastNote = note
        let path = Bundle.main.path(forResource: note.fileName, ofType: "wav")
        let url = URL(fileURLWithPath: path!)
        playMusic(url: url, numberOfLoops: 0)
    }
    
    public func stopiPadSound() {
        stopMusic()
    }
    
    // MARK: Private Methods
    
    private func setupBackground() {
        bgView = NeuronBgView(frame: CGRect.zero)
        view.addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
        bgView.config()
    }
    
    private func setupContainerView() {
        containerView = NeuronContainerView(frame: CGRect.zero)
        view.addSubview(containerView)
        containerView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
        containerView.isHidden = true
    }
}

extension TemplateViewController: TiltDetectorDelegate {
    public func onTiltUpdate(left: Bool, right: Bool, forword: Bool, backword: Bool) {
        sendToContentsWithEnum(.iPadTiltedForward(forword))
        sendToContentsWithEnum(.iPadTiltedBackward(backword))
        sendToContentsWithEnum(.iPadTiltedLeft(left))
        sendToContentsWithEnum(.iPadTiltedRight(right))
    }
}
