//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "PageProse")
 */
//#-hidden-code
playgroundPrologue()
powerOn()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, dcMotor(power1:power2:), dcMotor(slot:power:), playSound(note:), playSound(note:beat:), ledColor(color:style:), closeLed(), panelShow(color:), panelClear(), panelShow(expression:), getKnob(), getLight(), getTemperature(), getBlueTouched(), getYellowTouched(), getRedTounched(), getGreenTounched(), getDistance(), hasObstacle(), iPadTiltedForward(), iPadTiltedBackward(), iPadTiltedLeft(), iPadTiltedRight(), iPadSound(note:), stopiPadSound(), wait(duration:), setServo(port:angle:), readGyroSensor(axis:))
//#-code-completion(identifier, show, DCMotorSlot, slot1, slot2)
//#-code-completion(identifier, show, SoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundBeat, whole, half, quarter, eighth, sixteenth)
//#-code-completion(identifier, show, LEDColor, black, red, orange, yellow, green, cyan, blue, purple, white)
//#-code-completion(identifier, show, LEDStyle, light, marquee, breathing)
//#-code-completion(identifier, show, GyroAxis, x, y, z)
//#-code-completion(identifier, show, ServoPort, port1, port2)
//#-code-completion(identifier, show, Expression, angry, smile, smiley, happy, shock, sun, moon, fire, blank, forward, backward, left, right)
//#-code-completion(identifier, show, PadSoundNote, a4, b4, c4, d4, e4, f4, g4, c5)
//#-code-completion(keyword, show, for, func, if, else if, var, while, true)
//#-hidden-code
DispatchQueue.global().async {
//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
}
//#-end-hidden-code
