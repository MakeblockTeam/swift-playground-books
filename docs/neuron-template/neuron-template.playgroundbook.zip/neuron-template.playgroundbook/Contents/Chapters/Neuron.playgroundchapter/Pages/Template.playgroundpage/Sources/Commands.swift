//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

public func dcMotor(slot: DCMotorSlot, power: Int) {
    ActionTool.dcMotor(slot: slot, power: power)
}

public func dcMotor(power1: Int, power2: Int) {
    ActionTool.dcMotor(power1: power1, power2: power2)
}

public func playSound(note: SoundNote, beat: SoundBeat = .whole) {
    ActionTool.playSound(note: note, beat: beat)
}

public func ledColor(color: LEDColor, style: LEDStyle) {
    ActionTool.ledColor(color: color, style: style)
}

public func closeLed() {
    ActionTool.ledColor(color: .black, style: .light)
}

public func panelShow(expression: Expression) {
    ActionTool.panelShow(expression: expression)
}

public func panelShow(color: UIColor) {
    if let rgba = color.rgba() {
        ActionTool.panelColor(r: rgba.r, g: rgba.g, b: rgba.b)
    }
}

public func panelClear() {
    ActionTool.panelColor(r: 0, g: 0, b:0)
}

public func getKnob() -> Int {
    wait(duration: 0.1)
    ActionTool.getKnob()
    return contentListenr.getKnob
}

public func getLight() -> Int {
    wait(duration: 0.1)
    ActionTool.getLight()
    return contentListenr.getLight
}

public func getTemperature() -> Int {
    wait(duration: 0.1)
    ActionTool.getTemperature()
    return contentListenr.getTemperature
}

public func getBlueTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    return contentListenr.blueTouched
}

public func getYellowTouched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    return contentListenr.yellowTouched
}

public func getRedTounched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    return contentListenr.redTouched
}

public func getGreenTounched() -> Bool {
    wait(duration: 0.1)
    ActionTool.getFunnyTouch()
    return contentListenr.greenTouched
}

public func getDistance() -> Int {
    wait(duration: 0.1)
    ActionTool.getDistance()
    return contentListenr.getDistance
}

public enum GyroAxis: UInt8 {
    case x = 0x01
    case y = 0x02
    case z = 0x03
}

public func readGyroSensor(axis: GyroAxis) -> Int {
    wait(duration: 0.1)
    switch axis {
    case .x:
        return contentListenr.gyroXangle
    case .y:
        return contentListenr.gyroYangle
    case .z:
        return contentListenr.gyroZangle
    }
}

public func hasObstacle() -> Bool {
    wait(duration: 0.1)
    ActionTool.getDistance()
    return contentListenr.getDistance <= 10
}

public func iPadTiltedForward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedForward
}

public func iPadTiltedBackward() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedBackward
}

public func iPadTiltedLeft() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedLeft
}

public func iPadTiltedRight() -> Bool {
    wait(duration: 0.1)
    return contentListenr.iPadTiltedRight
}

public func iPadSound(note: PadSoundNote) {
    ActionTool.iPadSound(note: note)
}

public func stopiPadSound() {
    ActionTool.stopiPadSound()
}

public var getSoilmoisture: Int {
    wait(duration: 0.1)
    return contentListenr.getSoilmoisture
}

public func getVoice() -> Int {
    wait(duration: 0.1)
    return contentListenr.getVoice
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func setServo(port: ServoPort, angle: Int) {
    ActionTool.setServo(port: port, angle: angle)
}

public func turnLED(x: Int, y: Int, r: Int, g: Int, b: Int) {
    ActionTool.turnLED(x: x, y: y, r: r, g: g, b: b)
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
}
