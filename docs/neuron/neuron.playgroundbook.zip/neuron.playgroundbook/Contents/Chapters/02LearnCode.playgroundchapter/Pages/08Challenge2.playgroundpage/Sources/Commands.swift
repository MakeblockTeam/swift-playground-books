//
//  Commands.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import UIKit

public func dcMotor(power1: Int, power2: Int) {
    ActionTool.dcMotor(power1: power1, power2: power2)
    RuleManager.shared.append(ruleTask: RuleTask.dcMotor(power1: power1, power2: power2))
}

public func ledColor(color: LEDColor, style: LEDStyle = .light) {
    ActionTool.ledColor(color: color, style: style)
}

public func closeLed() {
    ActionTool.ledColor(color: .black, style: .light)
}

public func stop() {
    ActionTool.dcMotor(power1: 0, power2: 0)
}

public func getLight() -> Int {
    wait(duration: 0.1)
    ActionTool.getLight()
    return contentListenr.getLight
}

public func getDistance() -> Int {
    wait(duration: 0.1)
    ActionTool.getDistance()
    return contentListenr.getDistance
}

public func hasObstacle() -> Bool {
    wait(duration: 0.1)
    ActionTool.getDistance()
    return contentListenr.getDistance <= 10
}

public func playSound(note: SoundNote, beat: SoundBeat = .whole) {
    ActionTool.playSound(note: note, beat: beat)
}

public func panelShow(expression: Expression) {
    ActionTool.panelShow(expression: expression)
}

public func testText(_ text: String) {
    ActionTool.testText("\(text)")
}

public func powerOn() {
    ActionTool.powerOn()
}

public func wait(duration: Float) {
    ActionTool.wait(duration)
    RuleManager.shared.append(ruleTask: RuleTask.wait(duration: duration))
}
