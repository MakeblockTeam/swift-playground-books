//
//  NeuronChartsContainer.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/17.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit

struct ChartCellModel {
    var type: Int
    var index: Int
    var name: String
    var value: String
    var height: CGFloat
    var isConnected = true
    var isActive = true
    
    init(_ index: Int, _ type: Int, _ name: String, _ height: CGFloat, _ value: String, _ isConnected: Bool, _ isActive: Bool) {
        self.name = name
        self.value = value
        self.height = height
        self.isConnected = isConnected
        self.isActive = isActive
        self.index = index
        self.type = type
    }
    
    init() {
        type = 0
        index = 0
        name = ""
        height = 80
        value = ""
        isConnected = false
        isActive = true
    }
}

class NeuronChartsContainer: UIView, UITableViewDelegate, UITableViewDataSource {
    let chartCellID = "ChartCell"
    private let tableView = UITableView()
    private lazy var datasource: [ChartCellModel] = []

    private var orderedDatasource: [ChartCellModel] {
        return self.datasource.filter {$0.isConnected && $0.isActive}.sorted(by: { (model1, model2) -> Bool in
            return model1.index < model2.index
        })
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        backgroundColor = UIColor.clear
        tableView.isScrollEnabled = false
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.clear
        tableView.register(ChartsCell.self, forCellReuseIdentifier: chartCellID)
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        ajustUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func ajustUI() {
        tableView.frame = CGRect.init(x: 0, y: 150, width: bounds.width, height: bounds.height)
    }

    private func fetchDatasource() -> [ChartCellModel] {
        return cellModels(with: [.bluetooth, .power])
    }

    private func cellModels(with types: [BlockType]) -> [ChartCellModel] {
        return types.enumerated().map {
            self.cellModel(with: $0.element, index: $0.offset, value: "connected")
        }
    }

    private func cellModel(with type: BlockType, index: Int, value: String) -> ChartCellModel {
        return ChartCellModel.init(index, type.rawValue, type.valueName, type.height, value, true, true)
    }

    public func changeBlockState(type: BlockType, isConnected: Bool, animated: Bool = false, value: String = "") {
        let indexT = datasource.firstIndex { (model) -> Bool in
            return model.type == type.rawValue
        }
        let model = cellModel(with: type, index: datasource.count, value: value)
        if let index = indexT {
            datasource[index] = model
        } else {
            datasource.append(model)
        }
        tableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orderedDatasource.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: chartCellID) as? ChartsCell {
            cell.model = orderedDatasource[indexPath.row]
            return cell
        }
        return UITableViewCell.init(style: .default, reuseIdentifier: nil)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
}
