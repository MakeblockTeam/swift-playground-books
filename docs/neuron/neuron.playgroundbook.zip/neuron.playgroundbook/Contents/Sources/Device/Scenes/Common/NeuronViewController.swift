//
//  NeuronViewController.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/26.
//

import Foundation

public class NeuronViewController: LiveViewController {
    
    public let neuronListener = NeuronListener()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        SPBLECenter.shared.isNeuron = true
        currentBot.interpreterDelegate = neuronListener
        currentBot.blockContainerDelegate = neuronListener
    }
    
    public override func didReceive(data: Data) {
        currentBot.receivedData(data)
    }
}
