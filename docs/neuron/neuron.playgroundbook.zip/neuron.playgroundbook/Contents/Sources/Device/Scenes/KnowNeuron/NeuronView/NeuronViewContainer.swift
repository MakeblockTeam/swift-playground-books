//
//  NeuronViewContainer.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/17.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit
import PlaygroundSupport
public class NeuronViewContainer: UIView {
    let switchView: SwitchBar = SwitchBar.init(textOne: "Connect", textTwo: "Sensor", originPoint: CGPoint.init(x: 21, y: 20))
    let blocksContainer = NeuronBlocksContainer()
    let chartsContainer = NeuronChartsContainer()
    var originFrame: CGRect
    override public init(frame: CGRect) {
        originFrame = frame
        super.init(frame: frame)
        addSubview(blocksContainer)
        addSubview(chartsContainer)
        addSubview(switchView)
        configContainer()
        configSwitchBar()
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public func changeContainerState(_ isConnected: Bool, animated: Bool = false) {
        if isConnected {
            changeToConnectBLEState(animated)
        } else {
            changeToUnconnectBLEState(animated)
        }
    }

    public func changeBlockState(type: BlockType, isConnected: Bool, animated: Bool = false, value: String = "") {
        blocksContainer.changeBlockState(type: type, isConnected: isConnected, animated: animated)
        chartsContainer.changeBlockState(type: type, isConnected: isConnected, animated: animated, value: value)
    }

    private func configContainer() {
        blocksContainer.backgroundColor = UIColor.clear
        chartsContainer.backgroundColor = UIColor.clear
        backgroundColor = color(186, 225, 255)
        blocksContainer.frame = originFrame
        chartsContainer.frame = originFrame.offsetBy(dx: originFrame.width, dy: 0)
    }

    private func configSwitchBar() {
        switchView.didSelectAction = { [unowned self] index in
            self.changePage(index)
        }
    }

    private func changeToUnconnectBLEState(_ animated: Bool = false) {

        if animated {

        } else {

        }
    }

    private func changeToConnectBLEState(_ animated: Bool = false) {
        if animated {

        } else {

        }
    }

    private func changePage(_ page: Int, animated: Bool = true) {
        if animated {
            if page == 0 {
                blocksContainer.frame = originFrame
                chartsContainer.frame = originFrame.offsetBy(dx: originFrame.width, dy: -30)
            } else if page == 1 {
                blocksContainer.frame = originFrame.offsetBy(dx: originFrame.width, dy: -30)
                chartsContainer.frame = originFrame
            }
        } else {

        }
    }

}
