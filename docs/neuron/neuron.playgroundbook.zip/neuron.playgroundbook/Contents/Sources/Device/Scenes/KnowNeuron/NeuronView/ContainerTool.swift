//
//  ContainerTool.swift
//  NeuronView
//
//  Created by littleStrong on 2017/11/17.
//  Copyright © 2017年 Company. All rights reserved.
//

import UIKit

func fetchImage(_ name: String) -> UIImage {
    return UIImage.init(named: name) ?? UIImage.init()
}

func color(_ r: Int, _ g: Int, _ b: Int) -> UIColor {
    return UIColor.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: 1)
}
