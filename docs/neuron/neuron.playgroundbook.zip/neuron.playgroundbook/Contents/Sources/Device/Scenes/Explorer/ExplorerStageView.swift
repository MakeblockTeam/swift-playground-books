//
//  ExplorerStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/7.
//  Copyright © 2018年 makeblock. All rights reserved.
//

import UIKit

public class ExplorerStageView: DeckStageView {
    private let mainView = UIImageView(image: UIImage(named: "explorer/explorer_main_bg"))
    private let expressionView = UIImageView(image: UIImage(named: "explorer/explorer_blank"))
    private let distanceView = UIImageView(image: UIImage(named: "explorer/explorer_distance"))
    private let lightView = UIImageView(image: UIImage(named: "explorer/explorer_light"))
    private let soundView = UIImageView(image: UIImage(named: "explorer/explorer_sound"))
    private let power1View = UIImageView(image: UIImage(named: "explorer/explorer_power_0"))
    private let power2View = UIImageView(image: UIImage(named: "explorer/explorer_power_0"))

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "explorer/explorer_bg"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public func setDistance(enable: Bool) {
        distanceView.isHidden = !enable
        if enable {
            GCDDelay.delay(3.0) { [weak self] in
                self?.distanceView.isHidden = true
            }
        }
    }

    public func setLight(enable: Bool) {
        lightView.isHidden = !enable
        if enable {
            GCDDelay.delay(3.0) { [weak self] in
                self?.lightView.isHidden = true
            }
        }
    }

    public func setSound(enable: Bool) {
        soundView.isHidden = !enable
        if enable {
            GCDDelay.delay(3.0) { [weak self] in
                self?.soundView.isHidden = true
            }
        }
    }

    public func setSpeed1(_ speed: Int) {
        power1View.image = getImage(speed: speed)
    }

    public func setSpeed2(_ speed: Int) {
        power2View.image = getImage(speed: speed)
    }

    public func showExpression(_ type: Expression) {
        expressionView.image = UIImage(named: type.explorerImgName)
    }

    private func getImage(speed: Int) -> UIImage? {
        let value = abs(speed)
        if value < 5 {
            return UIImage(named: "explorer/explorer_power_0")
        } else if value >= 5 && value < 20 {
            return UIImage(named: "explorer/explorer_power_1")
        } else if value >= 20 && value < 40 {
            return UIImage(named: "explorer/explorer_power_2")
        } else if value >= 40 && value < 60 {
            return UIImage(named: "explorer/explorer_power_3")
        } else if value >= 60 && value < 80 {
            return UIImage(named: "explorer/explorer_power_4")
        } else {
            return UIImage(named: "explorer/explorer_power_5")
        }
    }

    override public func setupGameView() {
        mainView.backgroundColor = UIColor.clear
        addSubview(mainView)
        mainView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self)
            make.width.equalTo(362)
            make.height.equalTo(396)
            make.top.equalTo(110)
        }

        mainView.addSubview(expressionView)
        expressionView.snp.makeConstraints { (make) in
            make.width.equalTo(183)
            make.height.equalTo(203)
            make.top.equalTo(25)
            make.left.equalTo(25)
        }

        distanceView.isHidden = true
        mainView.addSubview(distanceView)
        distanceView.snp.makeConstraints { (make) in
            make.width.equalTo(70.5)
            make.height.equalTo(64)
            make.top.equalTo(13)
            make.left.equalTo(266.5)
        }

        lightView.isHidden = true
        mainView.addSubview(lightView)
        lightView.snp.makeConstraints { (make) in
            make.width.equalTo(70.5)
            make.height.equalTo(64)
            make.top.equalTo(88.5)
            make.left.equalTo(266.5)
        }

        soundView.isHidden = true
        mainView.addSubview(soundView)
        soundView.snp.makeConstraints { (make) in
            make.width.equalTo(70.5)
            make.height.equalTo(64)
            make.top.equalTo(166.5)
            make.left.equalTo(266.5)
        }

        mainView.addSubview(power1View)
        power1View.snp.makeConstraints { (make) in
            make.width.equalTo(26)
            make.height.equalTo(71)
            make.top.equalTo(299.2)
            make.left.equalTo(106.3)
        }

        mainView.addSubview(power2View)
        power2View.snp.makeConstraints { (make) in
            make.width.equalTo(26)
            make.height.equalTo(71)
            make.top.equalTo(299.2)
            make.left.equalTo(225.5)
        }
    }
}
