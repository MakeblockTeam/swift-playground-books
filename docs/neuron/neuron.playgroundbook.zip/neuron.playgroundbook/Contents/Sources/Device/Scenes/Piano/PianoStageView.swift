//
//  PianoStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/21.
//

import UIKit

public class PianoStageView: StageView {
    fileprivate let gifManager = SwiftyGifManager(memoryLimit: 60)
    fileprivate let gifView = UIImageView(frame: .zero)
    fileprivate var rangerView = UIView(frame: CGRect.zero)
    fileprivate var leftNum = UILabel(frame: CGRect.zero)
    fileprivate var rightNum = UILabel(frame: CGRect.zero)

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "stage"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func setRanger(value: Int) {
        guard value > 0 else {
            leftNum.text = "0"
            rightNum.text = "0"
            return
        }
        
        guard value < 99 else {
            leftNum.text = "9"
            rightNum.text = "9"
            return
        }
        
        let str = "\(value)"
        if str.count == 1 {
            leftNum.text = "0"
            rightNum.text = "\(str[str.startIndex])"
        } else {
            let left = "\(str[str.startIndex])"
            let right = "\(str[str.index(str.startIndex, offsetBy: 1)])"
            leftNum.text = left
            rightNum.text = right
        }
    }

    public override func setupGameView() {
        gifView.contentMode = .scaleAspectFill
        gifView.clipsToBounds = true
        addSubview(gifView)
        gifView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }

        gifView.setGifImage(UIImage(gifName: "piano"),
                            manager: self.gifManager,
                            loopCount: -1)
        gifView.startAnimatingGif()
        
        setupRangerView()
        self.addSubview(rangerView)
        rangerView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self).offset(-127)
            make.centerY.equalTo(self).offset(30)
            make.width.equalTo(97)
            make.height.equalTo(81)
        }
        
        setRanger(value: 98)
    }
    
    public override func updateLayout(frame: CGRect) {
        super.updateLayout(frame: frame)
        let mode = getScreenMode(frame: frame)
        switch mode {
        case .hFull, .hHalf:
            leftNum.font = UIFont.boldSystemFont(ofSize: 45)
            rightNum.font = UIFont.boldSystemFont(ofSize: 45)
            rangerView.snp.remakeConstraints { (make) in
                make.centerX.equalTo(self).offset(-127)
                make.centerY.equalTo(self).offset(30)
                make.width.equalTo(97)
                make.height.equalTo(81)
            }
        case .vHalf:
            leftNum.font = UIFont.boldSystemFont(ofSize: 30)
            rightNum.font = UIFont.boldSystemFont(ofSize: 30)
            rangerView.snp.remakeConstraints { (make) in
                make.centerX.equalTo(self).offset(-96)
                make.centerY.equalTo(self).offset(22)
                make.width.equalTo(73)
                make.height.equalTo(62)
            }
        case .vFull:
            leftNum.font = UIFont.boldSystemFont(ofSize: 60)
            rightNum.font = UIFont.boldSystemFont(ofSize: 60)
            rangerView.snp.remakeConstraints { (make) in
                make.centerX.equalTo(self).offset(-170)
                make.centerY.equalTo(self).offset(35)
                make.width.equalTo(136)
                make.height.equalTo(114)
            }
        }
    }
    
    private func setupRangerView() {
        addRangerBgView()
        addLeftNum()
        addRightNum()
    }
    
    fileprivate func addRangerBgView() {
        let image = UIImage(named: "piano-ranger")
        let bgView = UIImageView(image: image)
        bgView.contentMode = .scaleAspectFit
        rangerView.addSubview(bgView)
        bgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.rangerView)
        }
    }
    
    fileprivate func addLeftNum() {
        leftNum.text = "0"
        leftNum.textColor = UIColor.white
        leftNum.font = UIFont.boldSystemFont(ofSize: 30)
        leftNum.textAlignment = .center
        rangerView.addSubview(leftNum)
        leftNum.snp.makeConstraints { (make) in
            make.centerX.equalTo(rangerView).multipliedBy(0.62)
            make.centerY.equalTo(rangerView).multipliedBy(1.15)
            make.width.equalTo(rangerView.snp.width).multipliedBy(0.35)
            make.height.equalTo(rangerView.snp.height).multipliedBy(0.57)
        }
    }
    
    fileprivate func addRightNum() {
        rightNum.text = "0"
        rightNum.textColor = UIColor.white
        rightNum.font = UIFont.boldSystemFont(ofSize: 30)
        rightNum.textAlignment = .center
        rangerView.addSubview(rightNum)
        rightNum.snp.makeConstraints { (make) in
            make.centerX.equalTo(rangerView).multipliedBy(1.41)
            make.centerY.equalTo(rangerView).multipliedBy(1.15)
            make.width.equalTo(rangerView.snp.width).multipliedBy(0.35)
            make.height.equalTo(rangerView.snp.height).multipliedBy(0.57)
        }
    }
}
