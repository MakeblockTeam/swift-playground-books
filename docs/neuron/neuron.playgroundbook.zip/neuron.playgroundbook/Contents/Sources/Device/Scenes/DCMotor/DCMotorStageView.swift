//
//  DCMotorStageView.swift
//  Neuron
//
//  Created by CatchZeng on 2018/6/6.
//  Copyright © 2018年 makeblock. All rights reserved.
//

import UIKit

public class DCMotorStageView: DeckStageView {
    private let mainView = UIView(frame: .zero)
    private let motorView = UIImageView(image: UIImage(named: "dcmotor_main"))
    private let wheel1View = UIImageView(image: UIImage(named: "dcmotor_wheel1"))
    private let wheel2View = UIImageView(image: UIImage(named: "dcmotor_wheel2"))

    override public init(frame: CGRect) {
        super.init(frame: frame)
        setBgImage(UIImage(named: "dcmotor_bg"))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public func setSpeed1(_ speed: Int) {
        wheel1View.layer.removeAnimation(forKey: "wheel1View")
        if speed != 0 {
            wheel1View.layer.removeAllAnimations()
            let animation = createAnmation(speed: speed)
            wheel1View.layer.add(animation, forKey: "wheel1View")
        }
    }

    public func setSpeed2(_ speed: Int) {
        wheel2View.layer.removeAnimation(forKey: "wheel2View")
        if speed != 0 {
            let animation = createAnmation(speed: speed)
            wheel2View.layer.add(animation, forKey: "wheel2View")
        }
    }

    private func createAnmation(speed: Int) -> CABasicAnimation {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        if speed > 0 {
            animation.fromValue = 0
            animation.toValue = Double.pi*2
        } else {
            animation.fromValue = Double.pi*2
            animation.toValue = 0
        }

        let value = abs(speed) < 80 ? abs(speed) : 80
        let duration = 0.02*Double(101-value)
        animation.duration = duration
        animation.autoreverses = false
        animation.repeatCount = Float.infinity
        return animation
    }

    override public func setupGameView() {
        mainView.backgroundColor = UIColor.clear
        addSubview(mainView)
        mainView.snp.makeConstraints { (make) in
            make.center.equalTo(self)
            make.width.equalTo(390)
            make.height.equalTo(441)
        }

        mainView.addSubview(motorView)
        motorView.snp.makeConstraints { (make) in
            make.centerX.equalTo(mainView)
            make.width.equalTo(324)
            make.height.equalTo(388)
            make.top.equalTo(mainView)
        }

        mainView.addSubview(wheel1View)
        wheel1View.snp.makeConstraints { (make) in
            make.width.equalTo(157.5)
            make.height.equalTo(157.5)
            make.bottom.equalTo(mainView)
            make.left.equalTo(mainView)
        }

        mainView.addSubview(wheel2View)
        wheel2View.snp.makeConstraints { (make) in
            make.width.equalTo(157.5)
            make.height.equalTo(157.5)
            make.bottom.equalTo(mainView)
            make.right.equalTo(mainView)
        }
    }
}
