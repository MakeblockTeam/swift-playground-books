//
//  Rules.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/7/11.
//

import Foundation

public enum RuleTask {
    case connectBuzzer
    case dcMotor(power1: Int, power2: Int)
    case wait(duration: Float)
    case playSound(note: SoundNote, beat: SoundBeat)
    case hasObstacle
    case panelShow(expression: Expression)
    case getDistance(result: Int)
    case ledColor(color: LEDColor)
}
