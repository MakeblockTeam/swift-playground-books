//
//  Config.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/26.
//

import Foundation
import PlaygroundSupport

public let currentBot = Neuron(sender: SPBLECenter.shared)

public func setCurrentScene(chapter: Int = 0, page: Int = 0) {
    let vc = KnowNeuronViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setKnobScene(chapter: Int = 0, page: Int = 0) {
    let vc = KnobViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setTemperatureScene(chapter: Int = 0, page: Int = 0) {
    let vc = TemperatureViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setFunnyTouchScene(chapter: Int = 0, page: Int = 0) {
    let vc = FunnyTouchViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setDCMotorScene(page: Int = 0) {
    let vc = DCMotorViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.page = page
}

public func setExplorerScene(chapter: Int = 0, page: Int = 0) {
    let vc = ExplorerViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setSwordScene(chapter: Int = 0, page: Int = 0) {
    let vc = SwordViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public func setPianoScene(chapter: Int = 0, page: Int = 0) {
    let vc = PianoViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public var currentNeuronViewController: NeuronViewController? {
    if let vc = PlaygroundPage.current.liveView as? NeuronViewController {
        return vc
    }
    return nil
}

public var currentKnowNeuronViewController: KnowNeuronViewController? {
    if let vc = PlaygroundPage.current.liveView as? KnowNeuronViewController {
        return vc
    }
    return nil
}

public var currentKnobViewController: KnobViewController? {
    if let vc = PlaygroundPage.current.liveView as? KnobViewController {
        return vc
    }
    return nil
}

public var currentTemperatureViewController: TemperatureViewController? {
    if let vc = PlaygroundPage.current.liveView as? TemperatureViewController {
        return vc
    }
    return nil
}

public var currentFunnyTouchViewController: FunnyTouchViewController? {
    if let vc = PlaygroundPage.current.liveView as? FunnyTouchViewController {
        return vc
    }
    return nil
}

public var currentDCMotorViewController: DCMotorViewController? {
    if let vc = PlaygroundPage.current.liveView as? DCMotorViewController {
        return vc
    }
    return nil
}

public var currentExplorerViewController: ExplorerViewController? {
    if let vc = PlaygroundPage.current.liveView as? ExplorerViewController {
        return vc
    }
    return nil
}

public var currentSwordViewController: SwordViewController? {
    if let vc = PlaygroundPage.current.liveView as? SwordViewController {
        return vc
    }
    return nil
}

public var currentPianoViewController: PianoViewController? {
    if let vc = PlaygroundPage.current.liveView as? PianoViewController {
        return vc
    }
    return nil
}
