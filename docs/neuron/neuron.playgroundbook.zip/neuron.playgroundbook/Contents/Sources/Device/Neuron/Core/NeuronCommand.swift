//
//  NeuronCommand.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/10.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import UIKit

//起始位[0xf0]  blockno  type  subtype[可选]  commandID[可选] payload[n bytes]  校验位 结束位[0xf7]
public protocol NeuronCommand: MakeblockCommand {
    var prefix: UInt8 { get }
    var suffix: UInt8 { get }
    var blockNo: UInt8 { get }
    var type: UInt8? { get }
    var subType: UInt8? { get }
    var commandID: UInt8? { get }
    var payload: [UInt8]? { get }
}

extension NeuronCommand {
    public var prefix: UInt8 { return 0xf0 }

    public var suffix: UInt8 { return 0xf7 }

    public var blockNo: UInt8 { return 0x01 }

    public var type: UInt8? { return 0x5f }

    public var subType: UInt8? { return nil }

    public var commandID: UInt8? { return nil }

    public var payload: [UInt8]? { return nil }
}

extension NeuronCommand {
    public var data: Data {
        if let type = type {
            var bytes: [UInt8] = [prefix, blockNo, type]

            //Swift溢出运算符 -- http://www.68idc.cn/help/mobilesys/ios/20150221228740.html
            var checkSum: UInt8 = blockNo &+ type

            if let subType = subType {
                bytes.append(subType)
                checkSum = checkSum &+ subType
            }

            if let commandID = commandID {
                bytes.append(commandID)
                checkSum = checkSum &+ commandID
            }

            if let payload = payload {
                for byte in payload {
                    bytes.append(byte)
                    checkSum = checkSum &+ byte
                }
            }

            bytes.append(checkSum & 0x7f)
            bytes.append(suffix)

            return Data(bytes: bytes)

        } else {
            print("ERROR -- NeuronCommand: type is nil")
            return Data()
        }
    }
}

public struct HeartbeatCommand: NeuronCommand {
    public init () {}

    public var blockNo: UInt8 { return 0xff }

    public var type: UInt8? { return 0x10 }

    public var commandID: UInt8? { return 0x00 }
}
