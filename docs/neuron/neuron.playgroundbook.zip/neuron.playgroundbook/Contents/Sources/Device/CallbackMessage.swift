import PlaygroundSupport

public struct CallbackEncodingKey {
    public static let typeKey = "typeKey"
    public static let valueKey = "valueKey"

    public static let callback = "callback"
    public static let isConnected = "isConnected"

    public static let gyroXangle = "gyroXangle"
    public static let gyroYangle = "gyroYangle"
    public static let gyroZangle = "gyroZangle"

    public static let getSoilmoisture = "getSoilmoisture"
    public static let getVoice = "getVoice"
    public static let getKnob = "getKnob"
    public static let getLight = "getLight"
    public static let getTemperature = "getTemperature"
    public static let getDistance = "getDistance"

    public static let blueTouched = "blueTouched"
    public static let yellowTouched = "yellowTouched"
    public static let redTouched = "redTouched"
    public static let greenTouched = "greenTouched"

    public static let iPadTiltedForward = "iPadTiltedForward"
    public static let iPadTiltedBackward = "iPadTiltedBackward"
    public static let iPadTiltedLeft = "iPadTiltedLeft"
    public static let iPadTiltedRight = "iPadTiltedRight"

    public static let isBuzzerConnected = "isBuzzerConnected"
}

public enum SPCallbackCommand {
    case gyroXangle(Int)
    case gyroYangle(Int)
    case gyroZangle(Int)

    case getSoilmoisture(Int)
    case getVoice(Int)
    case getKnob(Int)
    case getLight(Int)
    case getTemperature(Int)
    case getDistance(Int)

    case blueTouched(Bool)
    case yellowTouched(Bool)
    case redTouched(Bool)
    case greenTouched(Bool)
    case isConnected(Bool)

    case iPadTiltedForward(Bool)
    case iPadTiltedBackward(Bool)
    case iPadTiltedLeft(Bool)
    case iPadTiltedRight(Bool)

    case isBuzzerConnected(Bool)
}

extension SPCallbackCommand: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[CallbackEncodingKey.typeKey], case let .string(type) = typeV else {
            return nil
        }
        switch type {
        case CallbackEncodingKey.gyroXangle:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .gyroXangle(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.gyroYangle:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .gyroYangle(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.gyroZangle:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .gyroZangle(intValue)
            } else {
                return nil
            }

        case CallbackEncodingKey.getSoilmoisture:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getSoilmoisture(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.getVoice:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getVoice(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.getKnob:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getKnob(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.getLight:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getLight(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.getTemperature:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getTemperature(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.getDistance:
            if let intValue = value.intValue(CallbackEncodingKey.valueKey) {
                self = .getDistance(intValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.blueTouched:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .blueTouched(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.yellowTouched:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .yellowTouched(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.redTouched:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .redTouched(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.greenTouched:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .greenTouched(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedForward:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedForward(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedBackward:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedBackward(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedLeft:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedLeft(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedRight:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedRight(boolValue)
            } else {
                return nil
            }
        case CallbackEncodingKey.isBuzzerConnected:
            if let boolValue = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .isBuzzerConnected(boolValue)
            } else {
                return nil
            }
        default:
            return nil
        }
    }

    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .gyroXangle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyroXangle.value
        case .gyroYangle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyroYangle.value
        case .gyroZangle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyroZangle.value
        case .getSoilmoisture(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getSoilmoisture.value
        case .getVoice(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getVoice.value
        case .getKnob(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getKnob.value
        case .getLight(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getLight.value
        case .getTemperature(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getTemperature.value
        case .getDistance(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.getDistance.value
        case .blueTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.blueTouched.value
        case .yellowTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.yellowTouched.value
        case .redTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.redTouched.value
        case .greenTouched(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.greenTouched.value
        case .iPadTiltedForward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedForward.value
        case .iPadTiltedBackward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedBackward.value
        case .iPadTiltedLeft(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedLeft.value
        case .iPadTiltedRight(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedRight.value
        case .isBuzzerConnected(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.isBuzzerConnected.value
        default: break
        }

        return .dictionary(dict)
    }
}
