import UIKit

public enum ScreenMode {
    case hHalf
    case hFull
    case vHalf
    case vFull
}

public func getScreenMode(frame: CGRect) -> ScreenMode {
    switch frame.size {
    case CGSize.init(width: 512, height: 768):
        return .hHalf
    case CGSize.init(width: 1024, height: 768):
        return .hFull
    case CGSize.init(width: 768, height: 1024):
        return .vFull
    case CGSize.init(width: 768, height: 512):
        return .vHalf
    default:
        return .hFull
    }
}

public func getAspect(frame: CGRect) -> CGFloat {
    switch getScreenMode(frame: frame) {
    case .vHalf:
        return 512 / 768
    case .vFull:
        return 1024 / 768
    default:
        return 1
    }
}

public enum CurtainPosition {
    case down
    case top
    case out
}
