//#-hidden-code
//
//  Contents.swift
//  Neuron
//
//  Created by CatchZeng on 2017/4/18.
//  Copyright © 2017-2018 Makeblock Co., Ltd. All rights reserved.
//

import PlaygroundSupport
import Foundation
//#-end-hidden-code
/*:#localized(key: "PageProse")
 */
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, .)
//#-code-completion(identifier, show, setDCMotor(leftSpeed:rightSpeed:), setLEDLight(r:g:b:), playMusic(type:), setFacePanel(x:y:isOn:), setFacePanel(type:), clearFacePanel(), playMusic(note:beat:), readLightSensor(), readSoundSensor(), readGyroRoll(), readGyroPitch(), readGyroYaw(), readGyroAccX(), readGyroAccY(), readGyroAccZ(), shaked(), readColorSensor(), buttonAPressed(), buttonBPressed(), buttonCPressed(), readPotentiometer(), iPadTiltedForward(), iPadTiltedBackward(), iPadTiltedLeft(), iPadTiltedRight(), wait(duration:), hasObstacle())
//#-code-completion(identifier, show, FacePanelType, angry, dizziness, happy, shock)
//#-code-completion(identifier, show, MusicType, start, jump, wrong, laugh, sad, wake, beeps, warning, explosion)
//#-code-completion(identifier, show, SoundNote, c4, d4, e4, f4, g4, a4, b4, c5)
//#-code-completion(identifier, show, SoundBeat, whole, half, quarter, eighth, sixteenth)
//#-code-completion(identifier, show, ColorType, unknown, white, purple, red, yellow, green, cyan, blue, pink, black)
//#-code-completion(keyword, show, for, func, if, let, var, while, true)
//#-hidden-code
DispatchQueue.global().async {
//#-end-hidden-code
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
}
//#-end-hidden-code
