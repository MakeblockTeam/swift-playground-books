//
//  CodeyInterpreter.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/8/2.
//

import Foundation

public enum CodeyTypeCode: UInt8 {
    case unknown = 0x00
    case button = 0x01
    case lightIntensity = 0x02
    case soundIntensity = 0x03
    case potentiometer = 0x04
    case gyro = 0x05
    case shake = 0x08
}

public enum RockyTypeCode: UInt8 {
    case unknown = 0x00
    case color = 0x02
    case obstacle = 0x08
}

extension Data {
    var deviceID: UInt8? {
        return count > 1 ? self.bytes[1] : nil
    }
    
    var commandID: UInt8? {
        return count > 4 ? self.bytes[4] : nil
    }
    
    var isCodey: Bool {
        return deviceID == 0x01
    }
    
    var isRocky: Bool {
        return deviceID == 0x02
    }
}

public protocol CodeyInterpreterDelegate: class {
    func onReceive(buttonAPressed: Bool, buttonBPressed: Bool, buttonCPressed: Bool)
    func onReceive(lightIntensity: Float)
    func onReceive(soundIntensity: Float)
    func onReceive(potentiometer: Float)
    func onReceive(roll: Float, pitch: Float, yaw: Float, accX: Float, accY: Float, accZ: Float)
    func onReceive(isShake: Bool)
    func onReceive(color: ColorType)
    func onReceive(hasObstacle: Bool)
}

open class CodeyInterpreter {
    public weak var delegate: CodeyInterpreterDelegate?
    
    public init() {}
    
    public func received(data: Data) {
        if data.isCodey {
            decodeCodey(data: data)
        } else if data.isRocky {
            decodeRocky(data: data)
        }
    }
    
    fileprivate func decodeRocky(data: Data) {
        let type = getRockyType(data: data)
        switch type {
        case .unknown:
            break
        case .color:
            if data.count < 7 {
                return
            }
            let colorValue = Int(data.bytes[5])
            if let color = ColorType.init(rawValue: colorValue) {
                delegate?.onReceive(color: color)
            }
        case .obstacle:
            if data.count < 7 {
                return
            }
            let intVlaue = Int(data.bytes[5])
            delegate?.onReceive(hasObstacle: intVlaue == 1 )
        }
    }
    
    fileprivate func decodeCodey(data: Data) {
        let type = getCodeyType(data: data)
        
        switch type {
        case .unknown:
            break
            
        case .button:
            if data.count < 9 {
                return
            }
            let buttonAPressed = Int(data.bytes[5]) == 0 ? false : true
            let buttonBPressed = Int(data.bytes[6]) == 0 ? false : true
            let buttonCPressed = Int(data.bytes[7]) == 0 ? false : true
            delegate?.onReceive(buttonAPressed: buttonAPressed, buttonBPressed: buttonBPressed, buttonCPressed: buttonCPressed)
            
        case .lightIntensity:
            if let value = decodeFloatValue(data: data) {
                delegate?.onReceive(lightIntensity: value)
            }
            
        case .potentiometer:
            if let value = decodeFloatValue(data: data) {
                delegate?.onReceive(potentiometer: value)
            }
        case .soundIntensity:
            if let value = decodeFloatValue(data: data) {
                delegate?.onReceive(soundIntensity: value)
            }
        case .gyro:
            guard let roll = decodeFloatValue(data: data),
                let pitch = decodeFloatValue(data: data, startIndex: 10, endIndex: 15),
                let yaw = decodeFloatValue(data: data, startIndex: 15, endIndex: 20),
                let accX = decodeFloatValue(data: data, startIndex: 20, endIndex: 25),
                let accY = decodeFloatValue(data: data, startIndex: 25, endIndex: 30),
                let accZ = decodeFloatValue(data: data, startIndex: 30, endIndex: 35) else {
                    return
            }
            delegate?.onReceive(roll: roll, pitch: pitch, yaw: yaw, accX: accX, accY: accY, accZ: accZ)
        case .shake:
            if data.count < 8 {
                return
            }
            let value = Int(data.bytes[5]) == 0 ? false : true
            delegate?.onReceive(isShake: value)
        }
    }
    
    private func decodeFloatValue(data: Data, startIndex: Int = 5, endIndex: Int = 10) -> Float? {
        if data.count < endIndex {
            return nil
        }
        let valueData = data.subdata(in: startIndex..<endIndex)
        let valueBytes = DataConverter.convert7to8bit(valueData.bytes)
        let value = ByteArrayConverter.fromByteArray(valueBytes, Float.self)
        return value
    }
    
    private func getCodeyType(data: Data) -> CodeyTypeCode {
        guard let commandID = data.commandID,
            let type = CodeyTypeCode.init(rawValue: commandID) else {
                return .unknown
        }
        return type
    }
    
    private func getRockyType(data: Data) -> RockyTypeCode {
        guard let commandID = data.commandID,
            let type = RockyTypeCode.init(rawValue: commandID) else {
                return .unknown
        }
        return type
    }
}
