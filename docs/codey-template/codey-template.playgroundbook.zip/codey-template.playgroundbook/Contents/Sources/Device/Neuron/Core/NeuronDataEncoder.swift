//
//  NeuronDataEncoder.swift
//  BytesKit
//
//  Created by CatchZeng on 2018/1/15.
//

import Foundation

public enum NeuronDataType {
    case byte
    case BYTE
    case short
    case SHORT
    case long
    case float

    public func eightBitLength() -> Int {
        switch self {
        case .byte: return 1
        case .BYTE: return 1
        case .short: return 2
        case .SHORT: return 2
        case .long: return 4
        case .float: return 4
        }
    }

    public func sevenBitLength() -> Int {
        switch self {
        case .byte: return 2
        case .BYTE: return 1
        case .short: return 3
        case .SHORT: return 2
        case .long: return 5
        case .float: return 5
        }
    }
}

open class NeuronDataEncoder {

    public static func convertTo8bit<T>(_ value: T, type: NeuronDataType) -> [UInt8] {
        var array = ByteArrayConverter.toByteArray(value)

        let length = type.eightBitLength()
        if array.count > length {
            let result = Array(array[0..<length])
            return result
        } else if array.count == length {
            return array
        } else {
            for _ in 0..<(length-array.count) {
                array.append(0x00)
            }
            return array
        }
    }

    public static func encodeValue<T>(_ value: T, type: NeuronDataType) -> [UInt8] {
        let bit = convertTo8bit(value, type: type)

        let result = DataConverter.convert8to7bit(bit)

        let length = type.sevenBitLength()
        if result.count > length {
            return Array(result[0..<length])
        } else if result.count == length {
            return result
        } else {
            debugPrint("[NeuronDataEncoder] encodeValue error: value-\(value) type-\(type)")
            return result
        }
    }
}
