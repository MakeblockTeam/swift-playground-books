import PlaygroundSupport

public struct CallbackEncodingKey {
    public static let typeKey = "typeKey"
    public static let valueKey = "valueKey"
    public static let callback = "callback"
    
    public static let iPadTiltedForward = "iPadTiltedForward"
    public static let iPadTiltedBackward = "iPadTiltedBackward"
    public static let iPadTiltedLeft = "iPadTiltedLeft"
    public static let iPadTiltedRight = "iPadTiltedRight"
    
    public static let readLightSensor = "readLightSensor"
    public static let getButtonState = "getButtonState"
    public static let buttonAPressed = "buttonAPressed"
    public static let buttonBPressed = "buttonBPressed"
    public static let buttonCPressed = "buttonCPressed"
    public static let readPotentiometer = "readPotentiometer"
    public static let readSoundSensor = "readSoundSensor"
    
    public static let roll = "roll"
    public static let pitch = "pitch"
    public static let yaw = "yaw"
    public static let accX = "accX"
    public static let accY = "accY"
    public static let accZ = "accZ"
    
    public static let shake = "shake"
    
    public static let color = "color"
    public static let hasObstacle = "hasObstacle"
}

public enum SPCallbackCommand {
    case iPadTiltedForward(Bool)
    case iPadTiltedBackward(Bool)
    case iPadTiltedLeft(Bool)
    case iPadTiltedRight(Bool)
    
    case readLightSensor(Float)
    case buttonAPressed(Bool)
    case buttonBPressed(Bool)
    case buttonCPressed(Bool)
    case readPotentiometer(Float)
    case readSoundSensor(Float)
    case hasObstacle(Bool)
    
    case roll(Float)
    case pitch(Float)
    case yaw(Float)
    case accX(Float)
    case accY(Float)
    case accZ(Float)
    
    case shake(Bool)
    case color(Int)
}

extension SPCallbackCommand: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[CallbackEncodingKey.typeKey], case let .string(type) = typeV else {
            return nil
        }
        switch type {
        case CallbackEncodingKey.iPadTiltedForward:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedForward(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedBackward:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedBackward(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedLeft:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedLeft(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedRight:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedRight(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.readLightSensor:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .readLightSensor(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.buttonAPressed:
            if let value = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .buttonAPressed(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.buttonBPressed:
            if let value = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .buttonBPressed(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.buttonCPressed:
            if let value = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .buttonCPressed(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.readPotentiometer:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .readPotentiometer(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.readSoundSensor:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .readSoundSensor(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.roll:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .roll(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.pitch:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .pitch(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.yaw:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .yaw(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.accX:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .accX(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.accY:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .accY(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.accZ:
            if let value = value.floatValue(CallbackEncodingKey.valueKey) {
                self = .accZ(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.shake:
            if let value = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .shake(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.color:
            if let value = value.intValue(CallbackEncodingKey.valueKey) {
                self = .color(value)
            } else {
                return nil
            }
        case CallbackEncodingKey.hasObstacle:
            if let value = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .hasObstacle(value)
            } else {
                return nil
            }
        default:
            return nil
        }
    }
    
    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .iPadTiltedForward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedForward.value
        case .iPadTiltedBackward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedBackward.value
        case .iPadTiltedLeft(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedLeft.value
        case .iPadTiltedRight(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedRight.value
        case .readLightSensor(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.readLightSensor.value
        case .buttonAPressed(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.buttonAPressed.value
        case .buttonBPressed(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.buttonBPressed.value
        case .buttonCPressed(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.buttonCPressed.value
        case .readPotentiometer(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.readPotentiometer.value
        case .readSoundSensor(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.readSoundSensor.value
        case .roll(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.roll.value
        case .pitch(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.pitch.value
        case .yaw(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.yaw.value
        case .accX(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.accX.value
        case .accY(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.accY.value
        case .accZ(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.accZ.value
        case .shake(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.shake.value
        case .color(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.color.value
        case .hasObstacle(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.hasObstacle.value
        }
        return .dictionary(dict)
    }
}
