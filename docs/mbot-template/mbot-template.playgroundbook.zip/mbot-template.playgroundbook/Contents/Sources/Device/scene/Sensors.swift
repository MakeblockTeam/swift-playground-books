//
//  Sensors.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/12.
//

import Foundation
import UIKit

public enum SensorType {
    case ultrasonic
    case lineFollower
    case light
    case joystick
    case temperature
    case humiture
    case volume
    case boardButton
    case gyro
    case flame
    case gas
    case fourButtons
    case touch
    case potentiometer
    case limitSwitch
    case compass
}

extension SensorType {
    public var name: String {
        switch self {
        case .ultrasonic:
            return NSLocalizedString("Ultrasonic Sensor", comment: "")
        case .lineFollower:
            return NSLocalizedString("Linefollow Sensor", comment: "")
        case .light:
            return NSLocalizedString("Light Sensor", comment: "")
        case .joystick:
            return NSLocalizedString("Joystick", comment: "")
        case .temperature:
            return NSLocalizedString("Temperature Sensor", comment: "")
        case .humiture:
            return NSLocalizedString("Humiture Sensor", comment: "")
        case .volume:
            return NSLocalizedString("Sound Sensor", comment: "")
        case .boardButton:
            return NSLocalizedString("OnBoard Button", comment: "")
        case .gyro:
            return NSLocalizedString("Gyroscope Sensor", comment: "")
        case .flame:
            return NSLocalizedString("Flame Sensor", comment: "")
        case .gas:
            return NSLocalizedString("Gas Sensor", comment: "")
        case .fourButtons:
            return NSLocalizedString("Button Sensor", comment: "")
        case .touch:
            return NSLocalizedString("Touch Sensor", comment: "")
        case .potentiometer:
            return NSLocalizedString("Potentiometer", comment: "")
        case .limitSwitch:
            return NSLocalizedString("Limit Switch", comment: "")
        case .compass:
            return NSLocalizedString("Compass", comment: "")
        }
    }
    
    public var icon: UIImage? {
        switch self {
        case .ultrasonic:
            return UIImage(named: "sensor-ultrasonic")
        case .lineFollower:
            return UIImage(named: "sensor-linefollow")
        case .light:
            return UIImage(named: "sensor-light")
        case .joystick:
            return UIImage(named: "sensor-joystick")
        case .temperature:
            return UIImage(named: "sensor-temperature")
        case .humiture:
            return UIImage(named: "sensor-humiture")
        case .volume:
            return UIImage(named: "sensor-sound")
        case .boardButton:
            return UIImage(named: "sensor-button-board")
        case .gyro:
            return UIImage(named: "sensor-gyroscope")
        case .flame:
            return UIImage(named: "sensor-flame")
        case .gas:
            return UIImage(named: "sensor-gas")
        case .fourButtons:
            return UIImage(named: "sensor-button")
        case .touch:
            return UIImage(named: "sensor-touch")
        case .potentiometer:
            return UIImage(named: "sensor-potentiometer")
        case .limitSwitch:
            return UIImage(named: "sensor-limit-switch")
        case .compass:
            return UIImage(named: "sensor-compass")
        }
    }
}
