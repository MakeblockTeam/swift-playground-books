//
//  RJ25DataInterpreter.swift
//  mZero-iOS
//
//  Created by CatchZeng on 2017/4/24.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit

open class RJ25DataInterpreter: NSObject {

    public func interpreter(data: Data, callback: ((_ index: Int, _ value: Float) -> Void)) {
        if data.bytes.count < 4 {
            callback(-1, 0)
            return
        }

        // get index
        let index = Int(data.bytes[2])

        // get value
        if data.bytes[3] == 0x02 { //Float
            if data.bytes.count < 10 {
                callback(-1, 0)
                return
            }

            let bytes = [data.bytes[4], data.bytes[5], data.bytes[6], data.bytes[7]]
            let value: Float = ByteArrayConverter.fromByteArray(bytes, Float.self)
            callback(index, value)

        } else if data.bytes[3] == 0x01 { //byte
            if data.bytes.count < 7 {
                callback(-1, 0)
                return
            }

            let byte = data.bytes[4]
            let value = Float(byte)
            callback(index, value)
            
        } else if data.bytes[3] == 0x03 { //Short
            if data.bytes.count < 10 {
                callback(-1, 0)
                return
            }
            
            let bytes = [data.bytes[4], data.bytes[5], data.bytes[6], data.bytes[7]]
            let value: Float = Float(ByteArrayConverter.fromByteArray(bytes, CShort.self))
            callback(index, value)
        }
    }
}
