//
//  RJ25Command.swift
//  mZero-iOS
//
//  Created by CatchZeng on 2017/7/17.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import Foundation

public protocol RJ25Command: MakeblockCommand {
    var index: UInt8 { get }
    var action: RJ25Action { get }
    var device: RJ25DeviceID? { get }
    var port: RJ25Port? { get }
    var slot: RJ25Slot? { get }
    var subCommand: UInt8? { get }
    var mode: UInt8? { get }
    var payload: [UInt8]? { get }
    var prefixA: UInt8 { get }
    var prefixB: UInt8 { get }
    var suffixA: UInt8 { get }
    var suffixB: UInt8 { get }
}

extension RJ25Command {
    public var index: UInt8 { return 0x00 }

    public var action: RJ25Action { return .write }

    public var device: RJ25DeviceID? { return nil }

    public var port: RJ25Port? { return nil }

    public var slot: RJ25Slot? { return nil }

    public var subCommand: UInt8? { return nil }

    public var mode: UInt8? { return nil }

    public var payload: [UInt8]? { return nil }

    public var prefixA: UInt8 { return 0xff }

    public var prefixB: UInt8 { return 0x55 }

    public var suffixA: UInt8 { return 0x0d }

    public var suffixB: UInt8 { return 0x0a }
}

extension RJ25Command {
    public var data: Data {
        var length = 2//index&action
        var bytes: [UInt8] = [prefixA, prefixB, index, action.rawValue]

        if let device = device {
            length += 1
            bytes.append(device.rawValue)
        }
        if let port = port {
            length += 1
            bytes.append(port.rawValue)
        }
        if let slot = slot {
            length += 1
            bytes.append(slot.rawValue)
        }
        if let subCommand = subCommand {
            length += 1
            bytes.append(subCommand)
        }
        if let mode = mode {
            length += 1
            bytes.append(mode)
        }
        if let payload = payload {
            length += payload.count
            for byte in payload {
                bytes.append(byte)
            }
        }

        bytes.insert(UInt8(length), at: 2)

        return Data(bytes: bytes)
    }

    public func intToUInt8Bytes(_ value: Int) -> (UInt8, UInt8) {
        let lowValue = UInt8(value & 0xff)
        let highValue = UInt8((value >> 8) & 0xff)
        return (lowValue, highValue)
    }
}

public struct VersionCommand: RJ25Command {
    public init () {}
    
    public var action: RJ25Action { return .read }

    public var device: RJ25DeviceID? { return .version }
}
