//
//  MBotCommands.swift
//  mZero-iOS
//
//  Created by CatchZeng on 2017/3/22.
//  Copyright © 2017年 Shenzhen Maker Works Technology Co., Ltd. All rights reserved.
//

import UIKit

public struct RGBLEDCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    private var mSlot: RJ25Slot
    
    public init(port: RJ25Port = .port7,
                slot: RJ25Slot = .slot2,
                position: RGBLEDPosition = .all,
                red: Int,
                green: Int,
                blue: Int,
                brightness: Float = 0.5) {
        mPort = port
        mSlot = slot
        let redValue = Float(red)*brightness
        let greenValue = Float(green)*brightness
        let blueValue = Float(blue)*brightness
        mPayload = [position.rawValue, UInt8(redValue), UInt8(greenValue), UInt8(blueValue)]
    }
    
    public var device: RJ25DeviceID? { return .rgbLED }
    
    public var port: RJ25Port? { return mPort }
    
    public var slot: RJ25Slot? { return mSlot }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct DCMotorCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    public init(port: RJ25Port, speed: Int) {
        mPort = port
        let speedValue = (port == .port9) ? -speed : speed
        let (low, high) = intToUInt8Bytes(speedValue)
        mPayload = [low, high]
    }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.dcMotor }
    
    public var port: RJ25Port? { return mPort }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct BuzzerCommand: RJ25Command {
    public var duration: MusicNoteDuration
    public var pitch: MusicNotePitch
    public var beat: Double
    private var mPayload: [UInt8]?
    
    public init(pitch: MusicNotePitch, duration: MusicNoteDuration, beat: Double = 1.0) {
        self.duration = duration
        self.pitch = pitch
        self.beat = beat
        let finalDuration = Double(duration.rawValue) * beat
        let (pitchLow, pitchHigh) = intToUInt8Bytes(pitch.rawValue)
        let (durationLow, durationHigh) = intToUInt8Bytes(Int(finalDuration))
        mPayload = [pitchLow, pitchHigh, durationLow, durationHigh]
    }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.buzzer }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct JoystickCommand: RJ25Command {
    public var leftSpeed: Int
    public var rightspeed: Int
    private var mPayload: [UInt8]?
    
    public init(leftSpeed: Int, rightspeed: Int) {
        self.leftSpeed = leftSpeed
        self.rightspeed = rightspeed
        let (lowLeft, highLeft) = intToUInt8Bytes(-leftSpeed)
        let (lowRight, highRight) = intToUInt8Bytes(rightspeed)
        mPayload = [lowLeft, highLeft, lowRight, highRight]
    }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.joystick }
    
    public var payload: [UInt8]? { return mPayload }
}

public enum PhysicalJoystickAxis: UInt8 {
    case x = 0x01
    case y = 0x02
}

public struct PhysicalJoystickCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    private var mPayload: [UInt8]?
    
    public init(index: UInt8, port: RJ25Port, axis: PhysicalJoystickAxis) {
        mIndex = index
        mPort = port
        mPayload = [axis.rawValue]
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.joystick }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct TemperatureCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    private var mSlot: RJ25Slot
    
    public init(index: UInt8, port: RJ25Port, slot: RJ25Slot) {
        mIndex = index
        mPort = port
        mSlot = slot
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var slot: RJ25Slot? { return mSlot }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.temperature }
}

public enum HumitureMode: UInt8 {
    case humidity = 0x00
    case temperature = 0x01
}

public struct HumitureCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    private var mPayload: [UInt8]?
    
    public init(index: UInt8, port: RJ25Port, mode: HumitureMode) {
        mIndex = index
        mPort = port
        mPayload = [mode.rawValue]
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.humiture }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct VolumeCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.volume }
}

public enum ButtonState: UInt8 {
    case pressed = 0x00
    case normal = 0x01
}

public struct BoardButtonCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPayload: [UInt8]?
    
    public init(index: UInt8, state: ButtonState) {
        mIndex = index
        mPayload = [state.rawValue]
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return .port7 }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.boardButton }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct UltraSonicCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port = .port3) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.ultrasonicSensor }
}

public enum GyroAxis: UInt8 {
    case x = 0x01
    case y = 0x02
    case z = 0x03
}

public struct GyroCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPayload: [UInt8]?
    
    public init(index: UInt8, axis: GyroAxis) {
        mIndex = index
        mPayload = [axis.rawValue]
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return .board } // 0x00 表示外置,固定的无需指定
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.gyro }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct FlameCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.flame }
}

public struct GasCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.gas }
}

public struct TouchCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.touch }
}

public struct PotentiometerCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.potentiometer }
}

public struct LimitSwitchCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    private var mSlot: RJ25Slot
    
    public init(index: UInt8, port: RJ25Port, slot: RJ25Slot) {
        mIndex = index
        mPort = port
        mSlot = slot
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var slot: RJ25Slot? { return mSlot }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.limitSwitch }
}

public struct CompassCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.compass }
}

public enum ButtonKey: UInt8 {
    case key1 = 0x01
    case key2 = 0x02
    case key3 = 0x03
    case key4 = 0x04
}

public struct FourButtonsCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    private var mPayload: [UInt8]?
    
    public init(index: UInt8, port: RJ25Port, key: ButtonKey) {
        mIndex = index
        mPort = port
        mPayload = [key.rawValue]
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.fourButtons }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct LineFollowerCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port = .port2) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.lineFollowerSensor }
}

public struct LightnessCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPort: RJ25Port
    
    public init(index: UInt8, port: RJ25Port = .port6) {
        mIndex = index
        mPort = port
    }
    
    public var action: RJ25Action { return .read }
    
    public var index: UInt8 { return mIndex }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.lightnessSensor }
}

public struct InfraredSendCommand: RJ25Command {
    public var mIndex: UInt8
    private var mPayload: [UInt8]?
    
    public init(index: UInt8, msg: String) {
        mIndex = index
        mPayload = msg.bytes
    }
    
    public var index: UInt8 { return mIndex }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.infraredSensor }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct SevenSegmentsLEDCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    
    public init(port: RJ25Port = .port1, value: Float) {
        mPort = port
        mPayload = ByteArrayConverter.toByteArray(value)
    }
    
    public var action: RJ25Action { return .write }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.sevenSegmentsLED }
    
    public var payload: [UInt8]? { return mPayload }
}

public enum FacePanelDisplayType: UInt8 {
    case character = 0x01
    case expression = 0x02
    case time = 0x03
    case number = 0x04
}

public struct FacePanelCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    
    public init(port: RJ25Port = .port1,
                type: FacePanelDisplayType,
                offsetX: UInt8,
                offsetY: UInt8,
                dataString: String) {
        mPort = port
        
        var array = [UInt8]()
        let hexString = dataString.replacingOccurrences(of: " ", with: "")
        if let hexArray = [UInt8].bytes(fromHexString: hexString) {
            array = hexArray
        }
        
        mPayload = [type.rawValue, offsetX, offsetY]
        mPayload?.append(contentsOf: array)
    }
    
    public var action: RJ25Action { return .write }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.facePanel }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct FacePanelCharacterCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    
    public init(port: RJ25Port = .port1,
                offsetX: UInt8,
                offsetY: UInt8,
                character: String) {
        mPort = port
        let count = UInt8(character.bytes.count)
        // 默认将字体垂直居中，输入的 y 值时将在 y=7 上做偏移
        mPayload = [FacePanelDisplayType.character.rawValue, offsetX, offsetY+7, count]
        mPayload?.append(contentsOf: character.bytes)
    }
    
    public var action: RJ25Action { return .write }
    
    public var port: RJ25Port? { return mPort }
    
    public var device: RJ25DeviceID? { return RJ25DeviceID.facePanel }
    
    public var payload: [UInt8]? { return mPayload }
}

public enum ShutterAction: UInt8 {
    case release = 0x00
    case pressed = 0x01
    case stopFocusing = 0x02
    case startFocusing = 0x03
}

public struct ShutterCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    
    public init(port: RJ25Port = .port7, action: ShutterAction) {
        mPort = port
        mPayload = [action.rawValue]
    }
    
    public var device: RJ25DeviceID? { return .shutter }
    
    public var port: RJ25Port? { return mPort }
    
    public var payload: [UInt8]? { return mPayload }
}

public struct ServoCommand: RJ25Command {
    private var mPayload: [UInt8]?
    private var mPort: RJ25Port
    private var mSlot: RJ25Slot
    
    public init(port: RJ25Port,
                slot: RJ25Slot,
                angle: Int) {
        mPort = port
        mSlot = slot
        var angleValue = angle
        if angle < 0 {
            angleValue = 0
        }
        if angle > 180 {
            angleValue = 180
        }
        mPayload = [UInt8(angleValue)]
    }
    
    public var device: RJ25DeviceID? { return .servo }
    
    public var port: RJ25Port? { return mPort }
    
    public var slot: RJ25Slot? { return mSlot }
    
    public var payload: [UInt8]? { return mPayload }
}
