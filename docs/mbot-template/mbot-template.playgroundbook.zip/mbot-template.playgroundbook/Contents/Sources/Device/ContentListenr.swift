//
//  SPMBot.swift
//  MBBlueToothCenter
//
//  Created by block Make on 2017/7/21.
//  Copyright © 2017年 block Make. All rights reserved.
//

import Foundation
import PlaygroundSupport

public typealias FloatCallback = ((Float) -> ())
public typealias BoolCallback = ((Bool) -> ())
public typealias IntCallback = ((Int) -> ())

public class ContentListenr: PlaygroundRemoteLiveViewProxyDelegate {
    public var isConnected: Bool = false
    
    public var ultrasonicValus: [Int: Float] = [Int: Float]()
    public var lightValus: [Int: Float] = [Int: Float]()
    public var lineFollowerValues: [Int: Int] = [Int: Int]()
    public var joystickValues: [Int: Int] = [Int: Int]()
    public var temperatureValues: [String: Float] = [String: Float]()
    public var humitureValus: [Int: Float] = [Int: Float]()
    public var volumeValus: [Int: Float] = [Int: Float]()
    public var boardButtonValus: [Int: Bool] = [Int: Bool]()
    public var gyroValus: [Int: Float] = [Int: Float]()
    public var flameValus: [Int: Float] = [Int: Float]()
    public var gasValus: [Int: Float] = [Int: Float]()
    public var fourButtonsValus: [Int: Bool] = [Int: Bool]()
    public var touchValus: [Int: Bool] = [Int: Bool]()
    public var potentiometerValus: [Int: Float] = [Int: Float]()
    public var limitSwitchValus: [String: Bool] = [String: Bool]()
    public var compassValus: [Int: Float] = [Int: Float]()
    
    public init() {}
    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
        guard let type = message.stringValue(CallbackEncodingKey.typeKey), let value = message.spValue(CallbackEncodingKey.valueKey) else {
            return
        }
        switch type {
        case CallbackEncodingKey.isConnected:
            if let finalValue = value.boolValue() {
                self.isConnected = finalValue
            }
        case CallbackEncodingKey.ultrasonic:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                ultrasonicValus[port] = finalValue
            }
        case CallbackEncodingKey.light:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                lightValus[port] = finalValue
            }
        case CallbackEncodingKey.lineFollower:
            if let finalValue = value.intValue(), let port = message.intValue(CallbackEncodingKey.port) {
                lineFollowerValues[port] = finalValue
            }
        case CallbackEncodingKey.joystick:
            if let finalValue = value.intValue(), let port = message.intValue(CallbackEncodingKey.port) {
                joystickValues[port] = finalValue
            }
        case CallbackEncodingKey.temperature:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port),
                let slot = message.intValue(CallbackEncodingKey.slot) {
                let key = "\(port)-\(slot)"
                temperatureValues[key] = finalValue
            }
        case CallbackEncodingKey.humiture:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                humitureValus[port] = finalValue
            }
        case CallbackEncodingKey.volume:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                volumeValus[port] = finalValue
            }
        case CallbackEncodingKey.boardButton:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                boardButtonValus[port] = (finalValue == 1.0)
            }
        case CallbackEncodingKey.gyro:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                gyroValus[port] = finalValue
            }
        case CallbackEncodingKey.flame:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                flameValus[port] = finalValue
            }
        case CallbackEncodingKey.gas:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                gasValus[port] = finalValue
            }
        case CallbackEncodingKey.fourButtons:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                fourButtonsValus[port] = (finalValue == 1.0)
            }
        case CallbackEncodingKey.touch:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                touchValus[port] = (finalValue == 1.0)
            }
        case CallbackEncodingKey.potentiometer:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                potentiometerValus[port] = finalValue
            }
        case CallbackEncodingKey.limitSwitch:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port),
                let slot = message.intValue(CallbackEncodingKey.slot) {
                let key = "\(port)-\(slot)"
                limitSwitchValus[key] = (finalValue == 1.0)
            }
        case CallbackEncodingKey.compass:
            if let finalValue = value.floatValue(), let port = message.intValue(CallbackEncodingKey.port) {
                compassValus[port] = finalValue
            }
        default:
            break
        }
    }

    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
        PlaygroundPage.current.finishExecution()
    }
}
