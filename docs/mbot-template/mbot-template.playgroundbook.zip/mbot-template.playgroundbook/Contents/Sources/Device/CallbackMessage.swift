//
//  CallbackMessage.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import Foundation

import PlaygroundSupport

public struct CallbackEncodingKey {
    public static let typeKey = "typeKey"
    public static let valueKey = "valueKey"
    public static let callback = "callback"
    
    public static let iPadTiltedForward = "iPadTiltedForward"
    public static let iPadTiltedBackward = "iPadTiltedBackward"
    public static let iPadTiltedLeft = "iPadTiltedLeft"
    public static let iPadTiltedRight = "iPadTiltedRight"
    
    // mBot
    public static let light = "light"
    public static let lineFollower = "lineFollower"
    public static let ultrasonic = "ultrasonic"
    public static let isConnected = "isConnected"
    public static let port = "port"
    public static let slot = "slot"
    public static let joystick = "joystick"
    public static let temperature = "temperature"
    public static let humiture = "humiture"
    public static let volume = "volume"
    public static let boardButton = "boardButton"
    public static let gyro = "gyro"
    public static let flame = "flame"
    public static let gas = "gas"
    public static let fourButtons = "fourButtons"
    public static let touch = "touch"
    public static let potentiometer = "potentiometer"
    public static let limitSwitch = "limitSwitch"
    public static let compass = "compass"
}

public enum SPCallbackCommand {
    case iPadTiltedForward(Bool)
    case iPadTiltedBackward(Bool)
    case iPadTiltedLeft(Bool)
    case iPadTiltedRight(Bool)
    
    // mBot
    case light(Int, Float)
    case lineFollower(Int, Int)
    case ultrasonic(Int, Float)
    case isConnected(Bool)
    case joystick(Int, Int)
    case temperature(Int, Int, Float)
    case humiture(Int, Float)
    case volume(Int, Float)
    case boardButton(Int, Float)
    case gyro(Int, Float)
    case flame(Int, Float)
    case gas(Int, Float)
    case fourButtons(Int, Float)
    case touch(Int, Float)
    case potentiometer(Int, Float)
    case limitSwitch(Int, Int, Float)
    case compass(Int, Float)
}

extension SPCallbackCommand: SPMessageConstructible {
    public init?(_ value: PlaygroundValue) {
        guard case let .dictionary(dict) = value, let typeV = dict[CallbackEncodingKey.typeKey], case let .string(type) = typeV else {
            return nil
        }
        switch type {
        case CallbackEncodingKey.iPadTiltedForward:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedForward(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedBackward:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedBackward(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedLeft:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedLeft(a)
            } else {
                return nil
            }
        case CallbackEncodingKey.iPadTiltedRight:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .iPadTiltedRight(a)
            } else {
                return nil
            }
            
        // mBot
        case CallbackEncodingKey.light:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .light(port, a)
            }
            return nil
        case CallbackEncodingKey.lineFollower:
            if let a = value.intValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .lineFollower(port, a)
            }
            return nil
        case CallbackEncodingKey.ultrasonic:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
               let port = value.intValue(CallbackEncodingKey.port) {
                self = .ultrasonic(port, a)
            }
            return nil
        case CallbackEncodingKey.isConnected:
            if let a = value.boolValue(CallbackEncodingKey.valueKey) {
                self = .isConnected(a)
            }
            return nil
        case CallbackEncodingKey.joystick:
            if let a = value.intValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .joystick(port, a)
            }
            return nil
        case CallbackEncodingKey.temperature:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port),
                let slot = value.intValue(CallbackEncodingKey.slot) {
                self = .temperature(port, slot, a)
            }
            return nil
        case CallbackEncodingKey.humiture:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .humiture(port, a)
            }
            return nil
        case CallbackEncodingKey.volume:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .volume(port, a)
            }
            return nil
        case CallbackEncodingKey.boardButton:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .boardButton(port, a)
            }
            return nil
        case CallbackEncodingKey.gyro:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .gyro(port, a)
            }
            return nil
        case CallbackEncodingKey.flame:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .flame(port, a)
            }
            return nil
        case CallbackEncodingKey.gas:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .gas(port, a)
            }
            return nil
        case CallbackEncodingKey.fourButtons:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .fourButtons(port, a)
            }
            return nil
        case CallbackEncodingKey.touch:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .touch(port, a)
            }
            return nil
        case CallbackEncodingKey.potentiometer:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .potentiometer(port, a)
            }
            return nil
        case CallbackEncodingKey.limitSwitch:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port),
                let slot = value.intValue(CallbackEncodingKey.slot) {
                self = .limitSwitch(port, slot, a)
            }
            return nil
        case CallbackEncodingKey.compass:
            if let a = value.floatValue(CallbackEncodingKey.valueKey),
                let port = value.intValue(CallbackEncodingKey.port) {
                self = .compass(port, a)
            }
            return nil
        default:
            return nil
        }
    }
    
    public var value: PlaygroundValue {
        var dict: [String: PlaygroundValue] = [:]
        switch self {
        case .iPadTiltedForward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedForward.value
        case .iPadTiltedBackward(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedBackward.value
        case .iPadTiltedLeft(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedLeft.value
        case .iPadTiltedRight(let value):
            dict[CallbackEncodingKey.valueKey] = value.value
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.iPadTiltedRight.value
        
        // mBot
        case .light(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.light.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = .floatingPoint(Double(a))
        case .lineFollower(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.lineFollower.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = .integer(a)
        case .ultrasonic(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.ultrasonic.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = .floatingPoint(Double(a))
        case .isConnected(let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.isConnected.value
            dict[CallbackEncodingKey.valueKey] = .boolean(a)
        case .joystick(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.joystick.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .temperature(let port, let slot, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.temperature.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.slot] = slot.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .humiture(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.humiture.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .volume(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.volume.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .boardButton(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.boardButton.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .gyro(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gyro.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .flame(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.flame.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .gas(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.gas.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .fourButtons(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.fourButtons.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .touch(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.touch.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .potentiometer(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.potentiometer.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .limitSwitch(let port, let slot, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.limitSwitch.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.slot] = slot.value
            dict[CallbackEncodingKey.valueKey] = a.value
        case .compass(let port, let a):
            dict[CallbackEncodingKey.typeKey] = CallbackEncodingKey.compass.value
            dict[CallbackEncodingKey.port] = port.value
            dict[CallbackEncodingKey.valueKey] = a.value
        }
        return .dictionary(dict)
    }
}
