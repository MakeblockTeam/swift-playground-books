//
//  BLETaskResponder.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import Foundation

public class BLETaskResponder: SPTaskResponder {
    
    public override func handle(command: MCommand) {
        switch command.action {
        case .move(let left, let right):
            move(left: left, right: right)
        case .setLEDStrip(let port, let slot, let r, let g, let b):
            setLEDStrip(port: port, slot: slot, r: r, g: g, b: b)
        case .setRGBLED(let port, let slot, let position, let r, let g, let b):
            setRGBLED(port: port, slot: slot, position: position, r: r, g: g, b: b)
        case .setShutter(let port, let action):
            setShutter(port: port, action: action)
        case .setServo(let port, let slot, let angle):
            setServo(port: port, slot: slot, angle: angle)
        case .set7SegmentDisplay(let port, let value):
            set7SegmentDisplay(port: port, value: value)
        case .play(let note, let beat):
            play(note: note, beat: beat)
        case .sendInfrared(let message):
            sendInfrared(message: message)
        case .setFan(let port, let speed):
            setFan(port: port, speed: speed)
        case .readUltrasonicSensor(let port):
            readUltrasonicSensor(port: port)
        case .readLightSensor(let port):
            readLightSensor(port: port)
        case .readLineFollowerSensor(let port):
            readLineFollowerSensor(port: port)
        case .readJoystick(let port, let axis):
            readJoystick(port: port, axis: axis)
        case .readTemperatureSensor(let port, let slot):
            readTemperatureSensor(port: port, slot: slot)
        case .readHumitureSensor(let port, let mode):
            readHumitureSensor(port: port, mode: mode)
        case .readSoundSensor(let port):
            readSoundSensor(port: port)
        case .readOnboardButton(let state):
            readOnboardButton(state: state)
        case .readGyroSensor(let port, let axis):
            readGyroSensor(port: port, axis: axis)
        case .readFlameSensor(let port):
            readFlameSensor(port: port)
        case .readGasSensor(let port):
            readGasSensor(port: port)
        case .readButton(let port, let key):
            readButton(port: port, key: key)
        case .readTouchSensor(let port):
            readTouchSensor(port: port)
        case .readPotentiometer(let port):
            readPotentiometer(port: port)
        case .readLimitSwitch(let port, let slot):
            readLimitSwitch(port: port, slot: slot)
        case .readCompass(let port):
            readCompass(port: port)
        case .setLEDPanel(let port, let text):
            setLEDPanel(port: port, text: text)
        default:
            break
        }
    }
    
    private func move(left: Int, right: Int) {
        currentBot.setDCMotor(leftSpeed: left, rightSpeed: right)
    }
    
    private func setLEDStrip(port: RJ25Port, slot: RJ25Slot, r: Int, g: Int, b: Int) {
        currentBot.setRGBLED(port: port, slot: slot, position: .all, red: r, green: g, blue: b)
    }
    
    private func setRGBLED(port: RJ25Port, slot: RJ25Slot, position: RGBLEDPosition, r: Int, g: Int, b: Int) {
        currentBot.setRGBLED(port: port, slot: slot, position: position, red: r, green: g, blue: b)
    }
    
    private func setShutter(port: RJ25Port, action: ShutterAction) {
        currentBot.setShutter(port: port, action: action)
    }
    
    private func setServo(port: RJ25Port,slot: RJ25Slot, angle: Int) {
        currentBot.setServo(port: port, slot: slot, angle: angle)
    }
    
    private func set7SegmentDisplay(port: RJ25Port, value: Float) {
        currentBot.setSevenSegmentsLED(port: port, value: value)
    }
    
    private func play(note: MusicNotePitch, beat: MusicNoteDuration) {
        currentBot.setBuzzer(pitch: note, duration: beat)
    }
    
    private func sendInfrared(message: String) {
        currentBot.sendInfrared(message: message)
    }
    
    private func setFan(port: RJ25Port, speed: Int) {
        currentBot.setFan(port: port, speed: speed)
    }
    
    private func readUltrasonicSensor(port: RJ25Port) {
        currentBot.readUltrasonicSensor(port) { (value) in
            sendToContentsWithEnum(.ultrasonic(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .ultrasonic, port: port, slot: nil, value: value)
        }
    }
    
    private func readLightSensor(port: RJ25Port) {
        currentBot.readLightSensor(port) { (value) in
            sendToContentsWithEnum(.light(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .light, port: port, slot: nil, value: value)
        }
    }
    
    private func readLineFollowerSensor(port: RJ25Port) {
        currentBot.readLineFollowerSensor(port) { (value) in
            sendToContentsWithEnum(.lineFollower(Int(port.rawValue), Int(value)))
            currentTemplateViewController?.appendSensor(type: .lineFollower, port: port, slot: nil, value: value)
        }
    }
    
    private func readJoystick(port: RJ25Port, axis: PhysicalJoystickAxis) {
        currentBot.readJoystick(port: port, axis: axis) { (value) in
            sendToContentsWithEnum(.joystick(Int(port.rawValue), Int(value)))
            currentTemplateViewController?.appendSensor(type: .joystick, port: port, slot: nil, value: value)
        }
    }
    
    private func readTemperatureSensor(port: RJ25Port, slot: RJ25Slot) {
        currentBot.readTemperatureSensor(port: port, slot: slot) { (value) in
            sendToContentsWithEnum(.temperature(Int(port.rawValue), Int(slot.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .temperature, port: port, slot: slot, value: value)
        }
    }
    
    private func readHumitureSensor(port: RJ25Port, mode: HumitureMode) {
        currentBot.readHumitureSensor(port: port, mode: mode) { (value) in
            sendToContentsWithEnum(.humiture(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .humiture, port: port, slot: nil, value: value)
        }
    }
    
    private func readSoundSensor(port: RJ25Port) {
        currentBot.readSoundSensor(port: port) { (value) in
            sendToContentsWithEnum(.volume(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .volume, port: port, slot: nil, value: value)
        }
    }
    
    private func readOnboardButton(state: ButtonState) {
        currentBot.readOnboardButton(state: state) { (value) in
            sendToContentsWithEnum(.boardButton(7, value))
            currentTemplateViewController?.appendSensor(type: .boardButton, port: .board, slot: nil, value: value)
        }
    }
    
    private func readGyroSensor(port: RJ25Port, axis: GyroAxis) {
        currentBot.readGyroSensor(port: port, axis: axis) { (value) in
            sendToContentsWithEnum(.gyro(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .gyro, port: port, slot: nil, value: value)
        }
    }
    
    private func readFlameSensor(port: RJ25Port) {
        currentBot.readFlameSensor(port: port) { (value) in
            sendToContentsWithEnum(.flame(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .flame, port: port, slot: nil, value: value)
        }
    }
    
    private func readGasSensor(port: RJ25Port) {
        currentBot.readGasSensor(port: port) { (value) in
            sendToContentsWithEnum(.gas(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .gas, port: port, slot: nil, value: value)
        }
    }
    
    private func readButton(port: RJ25Port, key: ButtonKey) {
        currentBot.readButton(port: port, key: key) { (value) in
            sendToContentsWithEnum(.fourButtons(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .fourButtons, port: port, slot: nil, value: value)
        }
    }
    
    private func readTouchSensor(port: RJ25Port) {
        currentBot.readTouchSensor(port: port) { (value) in
            sendToContentsWithEnum(.touch(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .touch, port: port, slot: nil, value: value)
        }
    }
    
    private func readPotentiometer(port: RJ25Port) {
        currentBot.readPotentiometer(port: port) { (value) in
            sendToContentsWithEnum(.touch(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .potentiometer, port: port, slot: nil, value: value)
        }
    }
    
    private func readLimitSwitch(port: RJ25Port, slot: RJ25Slot) {
        currentBot.readLimitSwitch(port: port, slot: slot) { (value) in
            sendToContentsWithEnum(.limitSwitch(Int(port.rawValue), Int(slot.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .limitSwitch, port: port, slot: slot, value: value)
        }
    }
    
    private func readCompass(port: RJ25Port) {
        currentBot.readCompass(port: port) { (value) in
            sendToContentsWithEnum(.compass(Int(port.rawValue), value))
            currentTemplateViewController?.appendSensor(type: .compass, port: port, slot: nil, value: value)
        }
    }
    
    private func setLEDPanel(port: RJ25Port, text: String) {
        currentBot.setLEDPanel(port: port, text: text);
    }
}
