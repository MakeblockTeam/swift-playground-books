//
//  Config.swift
//  Book_Sources
//
//  Created by CatchZeng on 2018/10/11.
//

import PlaygroundSupport
import Foundation

public func setCurrentScene(chapter: Int = 0, page: Int = 0) {
    let vc = TemplateViewController.init(nibName: nil, bundle: nil)
    PlaygroundPage.current.liveView = vc
    vc.chapter = chapter
    vc.page = page
}

public var currentTemplateViewController: TemplateViewController? {
    if let vc = PlaygroundPage.current.liveView as? TemplateViewController {
        return vc
    }
    return nil
}

public let currentBot = MBot()
